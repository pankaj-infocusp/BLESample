package breon.telematics.loneworkersafetyapp.android.domain.model

data class CheckInAssetDetail(
    val time: String
)
