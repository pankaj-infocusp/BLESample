package breon.telematics.loneworkersafetyapp.android.domain.model

data class OffDutyStatus(val name: String)