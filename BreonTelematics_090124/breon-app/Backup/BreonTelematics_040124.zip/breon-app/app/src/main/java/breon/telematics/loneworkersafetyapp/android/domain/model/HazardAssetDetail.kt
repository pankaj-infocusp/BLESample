package breon.telematics.loneworkersafetyapp.android.domain.model

data class HazardAssetDetail(
    val time: String
)
